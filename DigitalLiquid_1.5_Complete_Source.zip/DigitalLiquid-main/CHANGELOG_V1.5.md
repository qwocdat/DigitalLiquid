# DigitalLiquid 1.5 — Change Log

## Giao diện
- Đặt giao diện sáng làm mặc định cho theme Android, thanh trạng thái và thanh điều hướng.
- Thêm giao diện riêng cho hộp thoại, hộp chọn mô hình và thông báo trong ứng dụng; thông báo không còn dựa vào giao diện Toast mặc định của Android.
- Dùng màn hình/khung tab được cache; chuyển tab không dựng lại toàn bộ Activity.
- Giữ bản xem trước viên thuốc trên nền trắng để thấy rõ tương phản.
- Đổi nhãn kết nối trợ lý sang cách diễn đạt dành cho người dùng, không hiển thị tên nhà cung cấp nền tảng trong thông báo lỗi thông thường.

## Dynamic Island
- Thêm trạng thái dịch vụ riêng cho “đã gắn lớp phủ” và “đang hiển thị”, không chỉ dựa vào công tắc bật.
- Khi bật, kiểm tra xem lớp phủ đã được gắn thực sự chưa và thông báo bằng giao diện trong ứng dụng nếu không thành công.
- Tắt mặc định bốn quy tắc tự ẩn vốn có thể khiến viên thuốc biến mất ngay sau khi bật; bản 1.5 di chuyển cài đặt cũ một lần để tránh giữ lại các giá trị gây ẩn từ bản trước.
- Giữ nguyên logic phát hiện/quản lý hiệu ứng quay màn hình; chỉ thay cách hiển thị một số thông báo và cập nhật trạng thái lớp phủ.

## Build
- Tăng versionCode lên 6, versionName lên 1.5.
- Tắt minify/shrink ở debug để debug APK không bỏ mã/tài nguyên và dễ chẩn đoán; release vẫn shrink/minify.
- Thêm quy tắc ProGuard cho entry point của Android framework.
- Pin Gradle 8.9, phù hợp với Android Gradle Plugin 8.7.3, trong GitHub Actions.
