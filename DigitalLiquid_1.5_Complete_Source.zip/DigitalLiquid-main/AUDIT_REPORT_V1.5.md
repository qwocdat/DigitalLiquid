# DigitalLiquid 1.5 — Báo cáo rà soát

## Các thay đổi chính

1. **Trạng thái đảo nổi:** bổ sung hai trạng thái `SERVICE_ATTACHED` và `SERVICE_VISIBLE`; giao diện đọc trạng thái lớp phủ thực tế thay vì chỉ đọc công tắc lưu trong preferences.
2. **Tự ẩn:** bốn quy tắc tự ẩn (`AUTO_HIDE_SYSTEM_ISLAND`, `HIDE_WHEN_NATIVE_ACTIVITY`, `HIDE_WHEN_MEDIA_PLAYING`, `HIDE_WHEN_RINGER_UI`) mặc định tắt. Migration chạy một lần trong 1.5 để không giữ các giá trị tự ẩn gây lỗi từ cài đặt cũ.
3. **Chuyển tab:** dùng cache từng tab và đổi nội dung cuộn thay vì dựng lại toàn bộ khung Activity mỗi lần nhấn tab.
4. **Giao diện:** theme sáng mặc định; thêm dialog, model picker và notice do ứng dụng tự vẽ; thông báo hiển thị trong Activity hoặc lớp phủ riêng, nếu không thể hiển thị an toàn thì được xếp hàng để mở trong app lần sau; thay các lựa chọn/nhập liệu kiểu mặc định bằng thành phần đã tạo cho DigitalLiquid.
5. **Gói build:** debug không shrink/minify; release tiếp tục bật tối ưu và có `proguard-rules.pro`; Gradle CI được pin ở 8.9.
6. **Quay màn hình:** chỉ chạm phần trạng thái lớp phủ và cách hiển thị thông báo trong `IslandService.kt`; không sửa logic phát hiện trạng thái quay màn hình.

## Kiểm tra đã thực hiện

- 28 file Kotlin được parser của Kotlin compiler đọc; không phát hiện lỗi cú pháp (`syntax-error files=0`). Đây là kiểm tra cú pháp, **không phải** biên dịch/type-check đầy đủ.
- 5 file XML parse thành công.
- Workflow YAML parse thành công.
- Không tìm thấy `Toast.makeText`, `AlertDialog.Builder` hoặc `Spinner` trong mã Kotlin của app sau chỉnh sửa. `Toast.LENGTH_SHORT/LONG` chỉ được dùng làm hằng thời lượng; `LiquidNotice` tự vẽ nội dung thay vì gọi UI Toast hệ thống.
- Kiểm tra chuỗi không tìm thấy literal khóa OpenRouter dạng `sk-or-v1-...` trong mã Kotlin. Các thông tin kết nối hiện hữu và Firebase client config trong nguồn gốc vẫn được giữ vì thuộc cấu hình kết nối hiện tại; không coi Firebase web API key là quyền quản trị hoặc bí mật thay cho luật bảo mật backend.
- Đối chiếu diff `IslandService.kt`: các thay đổi thuộc trạng thái gắn/hiển thị, thông báo và mặc định tự ẩn; không thay đổi đường xử lý logic phát hiện/quản lý hiệu ứng quay màn hình.

## Chưa xác nhận được

- **Chưa chạy được `assembleDebug` trong môi trường tạo gói này.** Môi trường không có Android SDK/Gradle sẵn dùng và không thể tải các thành phần build qua mạng. Vì vậy không tuyên bố APK đã build thành công hoặc hoàn toàn không lỗi.
- GitHub Actions đã được cấu hình để chạy Java 17, Android SDK 35 và Gradle 8.9 rồi tạo artifact `DigitalLiquid-debug-apk`. Cần đẩy source lên GitHub và xem kết quả workflow để hoàn tất kiểm tra biên dịch.
- Cần thử trên điện thoại Xiaomi/Redmi/POCO chạy HyperOS 3+ sau khi build. Nhà sản xuất có thể chặn lớp phủ, quyền Trợ năng hoặc dịch vụ nền. Nếu app không có quyền hiển thị trên ứng dụng khác thì lớp phủ không thể hiện.

## Giới hạn giao diện hệ thống

DigitalLiquid tự vẽ các màn hình, hộp thoại và thông báo thuộc ứng dụng. Trang cấp quyền Android/HyperOS và thông báo foreground service bắt buộc vẫn do hệ điều hành kiểm soát; Android không cho app thay thế hoàn toàn giao diện các trang đó.
